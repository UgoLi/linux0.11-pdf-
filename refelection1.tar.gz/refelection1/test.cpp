/*************************************************************************
	> File Name: test.cpp
	> Author:UgoLi 
	> Mail: 2653920896@qq.com
	> Created Time: 2017年11月14日 星期二 13时49分33秒
 ************************************************************************/

#include<iostream>
#include "src/refelection.hpp"
#include "src/Precompile.h"
#include "src/StrKit.h"
#include <fstream>
#include <stdlib.h>
using namespace std;

//test
class TEST:public RFBaseClass{
public:
    DECLARE_CLASS(TEST);
public:
    PROPERTY_OP(TEST,vector<double>*,m_property)
    TEST():RFBaseClass(){}
    ~TEST(){}
    static void* createInstance(){return new TEST();}
    void registProperty(){
        //将设置函数句柄加入继承属性设置表中
        m_propertMap.insert(pair<string,RFBaseClass::setValue>("setm_property",setm_property));
    }
    void displayProperty(){
        vector<double> ve=*getm_property();
        cout.width(20);
        cout<<"TEST"<<": ";
        vector<double>::iterator it=ve.begin();
        for(int i=0;i<=3&&it!=ve.end();i++,it++){
            cout.width(6);
            cout<<*it<<" ";
        }
        cout<<endl;
    }
public:
    vector<double>* m_property;
};
REGIST_CLASS(TEST)

class STEP1:public RFBaseClass{
public:
    DECLARE_CLASS(STEP1);
public:
    PROPERTY_OP(STEP1,vector<double>*,m_property)
    STEP1():RFBaseClass(){}
    ~STEP1(){}
    static void* createInstance(){return new STEP1();}
    void registProperty(){
        //将设置函数句柄加入继承属性设置表中
        m_propertMap.insert(pair<string,RFBaseClass::setValue>("setm_property",setm_property));
    }
    void displayProperty(){
        vector<double> ve=*getm_property();
        cout.width(20);
        cout<<"STEP1"<<": ";
        vector<double>::iterator it=ve.begin();
        for(int i=0;i<=1&&it!=ve.end();i++,it++){
            cout.width(6);
            cout<<*it<<" ";
        }
        cout<<endl;
    }
public:
    vector<double>* m_property;
};
REGIST_CLASS(STEP1)

int main(){
try{    
    ifstream in("exec.txt",ios::in);
    if(!in) throw("No File:exec.txt");
    string tmp;
    vector<RFBaseClass*> execStep;
    while(getline(in,tmp)){
        tmp=StrKit::trim(tmp);
        vector<string> cmdArgStr=StrKit::split(tmp," ,:;");
        string className=cmdArgStr[0];
        vector<double>* classProperty=new vector<double>;
        vector<string>::iterator it=cmdArgStr.begin()+1;
        for(it;it!=cmdArgStr.end();it++){
            double a=atof(StrKit::trim((*it)).c_str());
            classProperty->push_back(a);
        }

        RFBaseClass* rfptr=(RFBaseClass*)ClassFactory::getInstance().getClassByName(className);
        rfptr->registProperty();
        rfptr->m_propertMap["setm_property"](rfptr,classProperty);

        execStep.push_back(rfptr);
    }
    //exec
    vector<RFBaseClass*>::iterator exe_it=execStep.begin();
    for(exe_it;exe_it!=execStep.end();exe_it++){
        (*exe_it)->displayProperty();
    }
}catch(exception& e){
    cout<<e.what()<<endl;
}catch(const char* s){
    cout<<s<<endl;
}
    return 0;
}

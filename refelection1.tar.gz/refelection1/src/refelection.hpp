/*************************************************************************
	> File Name: refelection_1.cpp
	> Author:UgoLi 
	> Mail: 2653920896@qq.com
	> Created Time: 2017年11月11日 星期六 08时56分00秒
 ************************************************************************/
#ifndef _REFELECTION_HPP
#define _REFELECTION_HPP

#include<iostream>
#include<map>
#include<string>
using namespace std;

typedef void* (*PTRCreateObject)(void);

//单例工厂
class ClassFactory{
private:
    map<string,PTRCreateObject> m_classMap;//名字、方法注册表
    ClassFactory();//构造函数私有化
public:
    static ClassFactory& getInstance();//建立工厂
    void registClass(string name,PTRCreateObject method);//注册生产类的方法
    void* getClassByName(string className);//通过指定的名字生产类
};

//向工厂注册类的动作
class RegistAction{
public:
    RegistAction(string name,PTRCreateObject method);
};
/*
 *macro:为需要动态创建的类声明 名字和注册动作
 */
#define DECLARE_CLASS(className)\
        string m_className##Name;\
        static RegistAction* m_className##dc;

/*
 *macro:向工厂注册类
 */
#define REGIST_CLASS(className)\
        RegistAction* className::m_className##dc=\
        new RegistAction(#className , className::createInstance);


//需要映射的基类申明
class RFBaseClass{
public:
    typedef void (*setValue)(RFBaseClass* t,void* c);//定义通用属性设置函数类型
public:
    RFBaseClass();
    virtual ~RFBaseClass();
    static void* createInstance();
    virtual void registProperty();
    virtual void displayProperty();
    map<string,setValue> m_propertMap;
};

/*
 *macro:为方便操作动态分配的类的属性  创建不同的函数名
 */
#define PROPERTY_OP(classType,PropertyType,PropertyName)\
        inline static void set##PropertyName(RFBaseClass* cptr,void* value){\
            classType* ptr=(classType*)cptr;\
            ptr->PropertyName=(PropertyType)value;\
        }\
        inline PropertyType get##PropertyName(void)const{\
            return PropertyName;\
        }

//test
/*
class RFHelloClass:public RFBaseClass{
public:
    DECLARE_CLASS(RFHelloClass);
public:
    PROPERTY_OP(RFHelloClass,string*,m_str)
    RFHelloClass():RFBaseClass();
    ~RFHelloClass();
    static void* createInstance();
    void registProperty();
    void displayProperty();
public:
    string* m_str;
};
REGIST_CLASS(RFHelloClass)


int main(){
    RFBaseClass* rfptr=(RFBaseClass*)ClassFactory::getInstance().getClassByName("RFHelloClass");    
    rfptr->registProperty();
    string str="hello world!";
    rfptr->m_propertMap["setm_str"](rfptr,&str);
    rfptr->displayProperty();
    return 0;
}
*/


#endif  //_REFELECTION_HPP










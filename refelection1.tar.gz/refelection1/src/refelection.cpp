/*************************************************************************
	> File Name: refelection.hpp
	> Author:UgoLi 
	> Mail: 2653920896@qq.com
	> Created Time: 2017年11月11日 星期六 08时56分00秒
 ************************************************************************/

#include "refelection.hpp"

/*##################################################################################*/
//单例工厂
ClassFactory::ClassFactory(){

}//构造函数私有化


//获取生产类的单例工厂
ClassFactory& ClassFactory::getInstance(){
    static ClassFactory sLo_factory;
    return sLo_factory;
}

//注册生产类的方法
void ClassFactory::registClass(string name,PTRCreateObject method){
    m_classMap.insert(pair<string,PTRCreateObject>(name,method));
}

//通过指定的名字生产类
void* ClassFactory::getClassByName(string className){
    map<string,PTRCreateObject>::const_iterator iter;
    iter=m_classMap.find(className);
    if(iter==m_classMap.end()){
        return NULL;
    }
    return iter->second();
}
/*##################################################################################*/

/*
 *需要动态创建类的注册动作
 */
RegistAction::RegistAction(string name,PTRCreateObject method){
        ClassFactory::getInstance().registClass(name,method);
    }


/*##################################################################################*/
//需要映射的基类申明实现
RFBaseClass::RFBaseClass(){}
RFBaseClass::~RFBaseClass(){}
void* RFBaseClass::createInstance(){return new RFBaseClass();}
void RFBaseClass::registProperty(){};
void RFBaseClass::displayProperty(){};

